import React, { Component } from 'react'
import AddAlertOutlinedIcon from '@mui/icons-material/AddAlertOutlined';
import PersonAddAltOutlinedIcon from '@mui/icons-material/PersonAddAltOutlined';
import ColorLensOutlinedIcon from '@mui/icons-material/ColorLensOutlined';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import MoreVertOutlinedIcon from '@mui/icons-material/MoreVertOutlined';
import PhotoOutlinedIcon from '@mui/icons-material/PhotoOutlined';
import { Button } from "@material-ui/core";
import '../displayNote/DisplayNote.scss'
import Icons from '../icons/Icons';
import Notes from '../../pages/notes/Notes';
import NoteService from '../../service/notesservice';

export class DisplayNote extends Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  render() {
    return (

      <div className="disp-container">
        {this.props.notesArray.map((item, index) => (
          <div>
            <input type="text" name="note" placeholder='title' />
            <input type="text" name="note" placeholder='discription' />

            <div className="disp-icons">
              <div className="icons-list">
                <Icons />

              </div>
            </div>
          </div>
        ))}
      </div>


    )
  }
}

export default DisplayNote
